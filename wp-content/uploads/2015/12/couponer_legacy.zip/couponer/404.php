<?php
get_header();
get_template_part( 'includes/inner_header' );
get_footer();
?>