<?php 
	if ( is_active_sidebar( 'sidebar-right_blog' ) ){ 
		dynamic_sidebar( 'sidebar-right_blog' );
	}
?>